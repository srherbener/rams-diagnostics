function varargout = probef(f,x0,y0)
%PROBEF   Record the time evolution of a probe in a field
%   P = PROBE(F, X0, Y0), where F is an array of scalar fields, returns the
%   time series of a probe located at point (X0, Y0), specified in physical
%   units (eg., in mm).  P is an array of size LENGTH(F).
%
%   [UX, UY] = PROBE(F, X0, Y0)  or  [UX, UY, UZ] = PROBE(F, X0, Y0) does
%   the same for a 2-component or a 3-component array of vector fields.
%
%   The value of the field at the location of the probe is interpolated
%   using Matlab's function INTERP2.
%
%   Example:
%      v = loadvec('*.vc7');
%      [ux, uy] = probef(v, 20, 30);
%      t = 1:length(v);
%      plot(t, ux, 'b', t, uy, 'r');
%      xlabel('time t');
%
%   See also SHOWF, MATRIXCOORDF.


%   F. Moisy, moisy_at_fast.u-psud.fr
%   Revision: 1.00,  Date: 2016/04/26
%   This function is part of the PIVMat Toolbox


% History:
% 2016/04/26: v1.00, first version.

error(nargchk(3,3,nargin));

vecmode = isfield(f(1),'vx');   % 1 for vector field, 0 for scalar field

for i = 1:numel(f)
    if vecmode
        ux(i) = interp2(f(i).x, f(i).y, f(i).vx', x0, y0);
        uy(i) = interp2(f(i).x, f(i).y, f(i).vy', x0, y0);
        if isfield(f(i),'vz')
            uz(i) = interp2(f(i).x, f(i).y, f(i).vz', x0, y0);
        end
    else
        s(i) = interp2(f(i).x, f(i).y, f(i).w', x0, y0);
    end 
end

if nargout==1
    varargout{1} = s;
elseif nargout==2
    varargout{1} = ux;
    varargout{2} = uy;
elseif nargout==3
    varargout{1} = ux;
    varargout{2} = uy;     
    varargout{3} = uz;
end
